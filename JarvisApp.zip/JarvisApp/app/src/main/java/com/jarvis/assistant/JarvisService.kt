package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Always-on listener. Hears speech, waits for the wake word "Jarvis", runs the command
 * (or asks Gemini) and speaks the answer. Runs as a foreground service so it keeps
 * working with the screen off.
 */
class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        @Volatile
        var running = false
        private const val CHANNEL = "jarvis"
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var busy = false
    private var awaitingCommand = false // heard "Jarvis" alone, next sentence is the command

    private lateinit var prefs: Prefs
    private lateinit var router: CommandRouter
    private lateinit var gemini: Gemini

    private val wakeRe = Regex("\\b(jarvis|jarvish|jarwis|travis|gervais|service)\\b[ ,.!?]*(.*)$", RegexOption.IGNORE_CASE)

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        router = CommandRouter(this, prefs)
        gemini = Gemini(prefs)
        tts = TextToSpeech(this, this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val note = Notification.Builder(this, CHANNEL)
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Jarvis\" followed by a command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, note)
        }
        running = true
        if (ttsReady) listen()
        return START_STICKY
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        t.language = Locale.UK
        t.setPitch(0.9f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { speaking = false; listen() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { speaking = false; listen() } }
        })
        ttsReady = true
        if (running) listen()
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------- speaking ----------

    private fun speak(text: String) {
        main.post {
            if (!ttsReady) { listen(); return@post }
            recognizer?.cancel()
            speaking = true
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }
    }

    // ---------- listening ----------

    private fun listen(delay: Long = 300) {
        main.postDelayed({
            if (!running || speaking || busy) return@postDelayed
            try {
                recognizer?.destroy()
                val r = SpeechRecognizer.createSpeechRecognizer(this)
                r.setRecognitionListener(listener)
                recognizer = r
                r.startListening(
                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                        .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                )
            } catch (e: Exception) {
                listen(2000)
            }
        }, delay)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> stopSelf()
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> listen(1500)
                else -> listen(400) // no speech / timeout: keep listening
            }
        }

        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
            if (text.isNullOrBlank()) { listen(); return }
            onHeard(text)
        }
    }

    private fun onHeard(text: String) {
        var command = text
        if (!awaitingCommand) {
            val m = wakeRe.find(text)
            if (m == null) { listen(); return } // ignore chatter without the wake word
            command = m.groupValues[2].trim()
            if (command.isEmpty()) {
                awaitingCommand = true
                speak("Yes, ${prefs.name}?")
                return
            }
        }
        awaitingCommand = false
        busy = true
        Thread {
            val reply = try {
                router.route(command) ?: gemini.ask(command)
            } catch (e: Exception) {
                "Something went wrong with that."
            }
            main.post { busy = false; speak(reply) }
        }.start()
    }
}
