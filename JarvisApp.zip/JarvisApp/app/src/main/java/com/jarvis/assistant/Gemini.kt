package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.DateFormat
import java.util.Date

/** Minimal Gemini client. Call from a background thread only. */
class Gemini(private val prefs: Prefs) {
    private val history = ArrayList<Pair<String, String>>() // role ("user"/"model"), text

    fun clear() = history.clear()

    fun ask(text: String): String {
        val key = prefs.key
        if (key.isBlank()) return "I need a Gemini API key for that. Open the Jarvis app and paste it in."
        history.add("user" to text)
        while (history.size > 20) history.removeAt(0)
        try {
            val contents = JSONArray()
            for ((role, t) in history) {
                contents.put(
                    JSONObject().put("role", role)
                        .put("parts", JSONArray().put(JSONObject().put("text", t)))
                )
            }
            val system = "You are JARVIS, a calm, dry-witted voice assistant running on the user's Samsung " +
                "Galaxy Tab A9+. Address the user as \"${prefs.name}\". Your replies are spoken aloud, so answer " +
                "in one to three short sentences of plain speech: no markdown, no lists, no emoji. " +
                "Current local time: ${DateFormat.getDateTimeInstance().format(Date())}."
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("maxOutputTokens", 400))

            val model = prefs.model.ifBlank { "gemini-2.5-flash" }
            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader()?.use { it.readText() } ?: ""
            conn.disconnect()

            if (code !in 200..299) {
                history.removeAt(history.size - 1)
                return when (code) {
                    403 -> "That Gemini key was rejected. Check it in the app."
                    429 -> "The free limit was reached. Try again in a minute."
                    else -> {
                        val msg = try { JSONObject(resp).getJSONObject("error").getString("message") } catch (e: Exception) { "error $code" }
                        "The service returned an error: $msg"
                    }
                }
            }
            val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text")).append(' ')
            val out = sb.toString().replace(Regex("[*_`#]"), "").trim().ifBlank { "I have nothing to add." }
            history.add("model" to out)
            return out
        } catch (e: Exception) {
            if (history.isNotEmpty() && history.last().first == "user") history.removeAt(history.size - 1)
            return "I can't reach the network right now."
        }
    }
}
