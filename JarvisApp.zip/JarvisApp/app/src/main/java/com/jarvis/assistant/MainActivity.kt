package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var keyBox: EditText
    private lateinit var nameBox: EditText
    private lateinit var modelBox: EditText
    private lateinit var countryBox: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(Color.parseColor("#6F95A6")); textSize = 13f
        setPadding(0, dp(14), 0, dp(2))
    }

    private fun field(hint: String, value: String, password: Boolean = false) = EditText(this).apply {
        setText(value); this.hint = hint
        setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#446"))
        inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#050B12"))
            setPadding(dp(24), dp(32), dp(24), dp(32))
        }
        root.addView(TextView(this).apply {
            text = "JARVIS"; textSize = 28f; setTextColor(Color.parseColor("#35E0FF")); letterSpacing = 0.3f
        })
        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, dp(12), 0, dp(8)) }
        root.addView(status)

        root.addView(label("Gemini API key (free: aistudio.google.com/apikey)"))
        keyBox = field("Paste key", prefs.key, true); root.addView(keyBox)
        root.addView(label("What should I call you?"))
        nameBox = field("sir", prefs.name); root.addView(nameBox)
        root.addView(label("Country code for 10-digit numbers"))
        countryBox = field("91", prefs.country); root.addView(countryBox)
        root.addView(label("Gemini model"))
        modelBox = field("gemini-2.5-flash", prefs.model); root.addView(modelBox)
        root.addView(button("Save settings") { save(); refresh() })

        root.addView(label("Setup (do each once)"))
        root.addView(button("1. Grant permissions (mic, phone, SMS, contacts)") { askPermissions() })
        root.addView(button("2. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("3. Turn on Accessibility for Jarvis") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("4. Battery: set Jarvis to Unrestricted") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        toggle = button("Start Jarvis") { toggleService() }
        root.addView(View(this), LinearLayout.LayoutParams(1, dp(16)))
        root.addView(toggle)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#050B12")); addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun save() {
        prefs.key = keyBox.text.toString().trim()
        prefs.name = nameBox.text.toString().trim().ifBlank { "sir" }
        prefs.country = countryBox.text.toString().trim().ifBlank { "91" }
        prefs.model = modelBox.text.toString().trim().ifBlank { "gemini-2.5-flash" }
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun askPermissions() {
        val list = mutableListOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(list.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun toggleService() {
        save()
        if (JarvisService.running) {
            stopService(Intent(this, JarvisService::class.java))
            JarvisService.running = false
        } else {
            if (!granted(Manifest.permission.RECORD_AUDIO)) { askPermissions(); return }
            startForegroundService(Intent(this, JarvisService::class.java))
        }
        status.postDelayed({ refresh() }, 400)
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName)
    }

    private fun tick(ok: Boolean) = if (ok) "✓" else "✗"

    private fun refresh() {
        status.text = "Microphone ${tick(granted(Manifest.permission.RECORD_AUDIO))}   " +
            "Phone ${tick(granted(Manifest.permission.CALL_PHONE))}   " +
            "SMS ${tick(granted(Manifest.permission.SEND_SMS))}   " +
            "Contacts ${tick(granted(Manifest.permission.READ_CONTACTS))}\n" +
            "Over other apps ${tick(Settings.canDrawOverlays(this))}   " +
            "Accessibility ${tick(a11yOn())}   " +
            "API key ${tick(prefs.key.isNotBlank())}\n" +
            if (JarvisService.running) "Jarvis is listening. Say \"Jarvis, ...\"" else "Jarvis is stopped."
        toggle.text = if (JarvisService.running) "Stop Jarvis" else "Start Jarvis"
    }
}
