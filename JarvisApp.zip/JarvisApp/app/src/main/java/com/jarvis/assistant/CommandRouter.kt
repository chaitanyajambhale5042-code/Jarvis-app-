package com.jarvis.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Turns a spoken sentence into a phone action. Returns the spoken reply, or null when the
 * sentence is not a command (it then goes to Gemini). Runs on a background thread.
 */
class CommandRouter(private val ctx: Context, private val prefs: Prefs) {

    private val main = Handler(Looper.getMainLooper())
    private val words = mapOf(
        "a" to 1, "an" to 1, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
        "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "fifteen" to 15,
        "twenty" to 20, "thirty" to 30, "forty" to 40, "sixty" to 60
    )

    private fun granted(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun num(s: String): Int? = s.toIntOrNull() ?: words[s]

    @Suppress("DEPRECATION")
    private fun wake() {
        try {
            val pm = ctx.getSystemService(PowerManager::class.java)
            pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "jarvis:wake"
            ).acquire(5000)
        } catch (_: Exception) {
        }
    }

    private fun launch(i: Intent) {
        wake()
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    // ---------- contacts ----------

    private fun findNumber(name: String): String? {
        val n = name.lowercase().trim()
        if (Regex("^[\\d\\s+()-]{5,}$").matches(n)) return n
        if (!granted(Manifest.permission.READ_CONTACTS)) return null
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ), null, null, null
        ) ?: return null
        c.use {
            var best: String? = null
            while (it.moveToNext()) {
                val dn = it.getString(0)?.lowercase() ?: continue
                val num = it.getString(1) ?: continue
                if (dn == n) return num
                if (best == null && (dn.contains(n) || n.contains(dn))) best = num
            }
            return best
        }
    }

    private fun digits(number: String): String {
        val d = number.replace(Regex("[^\\d+]"), "")
        return if (d.startsWith("+")) d.substring(1) else if (d.length == 10) prefs.country + d else d
    }

    // ---------- actions ----------

    private fun call(number: String): String {
        if (!granted(Manifest.permission.CALL_PHONE)) return "I need the phone permission. Open the Jarvis app and grant permissions."
        return try {
            val tm = ctx.getSystemService(TelecomManager::class.java)
            val n = number.replace(Regex("[^\\d+]"), "")
            tm.placeCall(Uri.fromParts("tel", n, null), Bundle())
            "Calling."
        } catch (e: Exception) {
            "I couldn't place the call."
        }
    }

    private fun sms(number: String, body: String): String {
        if (!granted(Manifest.permission.SEND_SMS)) return "I need the SMS permission. Open the Jarvis app and grant permissions."
        return try {
            val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
            else @Suppress("DEPRECATION") SmsManager.getDefault()
            val n = number.replace(Regex("[^\\d+]"), "").let { if (it.length == 10) "+" + prefs.country + it else it }
            sm.sendMultipartTextMessage(n, null, sm.divideMessage(body), null, null)
            "Message sent."
        } catch (e: Exception) {
            "I couldn't send the text. This tablet may not support SMS."
        }
    }

    private fun whatsapp(number: String, body: String): String {
        val a11y = JarvisAccessibilityService.instance
        launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${digits(number)}?text=${Uri.encode(body)}")))
        if (a11y == null) return "WhatsApp is open with your message. Tap send."
        // Try to press Send once the chat has loaded.
        Thread {
            for (i in 0 until 6) {
                Thread.sleep(1500)
                if (a11y.clickLabel("Send")) break
            }
        }.start()
        return "Sending your WhatsApp message."
    }

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val n = name.lowercase().trim()
        val hit = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: return "I couldn't find an app called $name."
        val li = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "I couldn't open $name."
        launch(li)
        return "Opening ${hit.loadLabel(pm)}."
    }

    private var torch = false
    private fun flashlight(on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "This tablet has no flashlight."
            cm.setTorchMode(id, on)
            torch = on
            if (on) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) {
            "I couldn't use the flashlight."
        }
    }

    private fun a11y(block: (JarvisAccessibilityService) -> Boolean, ok: String): String {
        val s = JarvisAccessibilityService.instance
            ?: return "Accessibility control is off. Turn it on for Jarvis in the app."
        return if (block(s)) ok else "I couldn't do that."
    }

    // ---------- routing ----------

    fun route(raw: String): String? {
        val text = raw.trim().replace(Regex("[.!?]+$"), "")
        val s = text.lowercase().replace(".", "")
        val name = prefs.name
        var m: MatchResult?

        if (s in setOf("stop", "be quiet", "quiet", "cancel", "never mind")) return "Of course."
        if (Regex("^(hi|hello|hey)( jarvis)?$").matches(s)) return "Hello, $name. How can I help?"

        // messages
        val msgRe = Regex(
            "^(?:please )?(?:send|text|message|whatsapp|sms)\\b(?: an?)?(?: whatsapp| sms| text)?(?: message| msg)?(?: to)? (.+?)(?: on whatsapp| by sms)? (?:saying that|saying|that says|and say|to say) (.+)$",
            RegexOption.IGNORE_CASE
        )
        m = msgRe.find(text)
        if (m != null) {
            val who = m.groupValues[1].replace(Regex("\\s+(on|via|by) (whatsapp|sms|text)$", RegexOption.IGNORE_CASE), "").trim()
            val body = m.groupValues[2].trim()
            val number = findNumber(who)
                ?: return "I couldn't find $who in your contacts, $name."
            return if (text.contains("whatsapp", true)) whatsapp(number, body) else sms(number, body)
        }

        // calls
        m = Regex("^(?:please )?(?:call|dial|phone|ring) (.+)$").find(s)
        if (m != null) {
            val who = m.groupValues[1].trim()
            val number = findNumber(who) ?: return "I couldn't find $who in your contacts, $name."
            return call(number)
        }

        // time, date, battery
        if (Regex("\\bwhat('?s| is)? (the )?time\\b|\\bcurrent time\\b|^time$").containsMatchIn(s))
            return "It's ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())}, $name."
        if (Regex("^(what('?s| is) )?(the |today'?s )?(date|day)( today)?$").matches(s))
            return "Today is ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())}."
        if (s.contains("battery")) {
            val bm = ctx.getSystemService(BatteryManager::class.java)
            return "Battery is at ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} percent."
        }

        // timer and alarm (real ones)
        m = Regex("(?:set |start )?(?:a |an )?timer (?:for )?(\\w+) ?(second|minute|min|hour)s?").find(s)
        if (m != null) {
            val n = num(m.groupValues[1])
            if (n != null) {
                val unit = m.groupValues[2]
                val secs = n * (if (unit.startsWith("sec")) 1 else if (unit.startsWith("h")) 3600 else 60)
                launch(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                return "Timer set for $n $unit${if (n == 1) "" else "s"}."
            }
        }
        m = Regex("alarm (?:for|at) (\\d{1,2})(?:[: ](\\d{2}))? ?(am|pm|a m|p m)?").find(s)
        if (m != null) {
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifBlank { "0" }.toInt()
            val ap = m.groupValues[3].replace(" ", "")
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            launch(
                Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
                    .putExtra(AlarmClock.EXTRA_MINUTES, min).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            )
            return "Alarm set for ${"%d:%02d".format(h, min)}."
        }

        // hardware
        if (Regex("(turn|switch) on (the )?(flashlight|torch)|^(flashlight|torch) on$").containsMatchIn(s)) return flashlight(true)
        if (Regex("(turn|switch) off (the )?(flashlight|torch)|^(flashlight|torch) off$").containsMatchIn(s)) return flashlight(false)
        val audio = ctx.getSystemService(AudioManager::class.java)
        if (Regex("volume up|louder|increase (the )?volume").containsMatchIn(s)) {
            repeat(3) { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
            return "Volume up."
        }
        if (Regex("volume down|quieter|lower (the )?volume|decrease (the )?volume").containsMatchIn(s)) {
            repeat(3) { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
            return "Volume down."
        }
        if (Regex("^(mute|silence)( the)?( tablet| sound)?$").matches(s)) {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            return "Muted."
        }

        // screen control (Accessibility)
        if (s in setOf("go back", "back", "press back"))
            return a11y({ it.global(AccessibilityService.GLOBAL_ACTION_BACK) }, "Going back.")
        if (s in setOf("go home", "home", "press home", "home screen", "go to home screen"))
            return a11y({ it.global(AccessibilityService.GLOBAL_ACTION_HOME) }, "Going home.")
        if (s in setOf("recent apps", "recents", "show recent apps", "show recents"))
            return a11y({ it.global(AccessibilityService.GLOBAL_ACTION_RECENTS) }, "Here are your recent apps.")
        if (s.contains("notification"))
            return a11y({ it.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) }, "Here are your notifications.")
        if (s.contains("quick settings"))
            return a11y({ it.global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) }, "Quick settings.")
        if (s.contains("screenshot") || s.contains("screen shot"))
            return a11y({ it.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) }, "Screenshot taken.")
        if (Regex("lock (the )?(screen|tablet)|turn off (the )?screen").containsMatchIn(s))
            return a11y({ it.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) }, "Locking the screen.")
        m = Regex("^scroll (up|down|left|right)$").find(s)
        if (m != null) {
            val dir = m.groupValues[1]
            return a11y({ it.scroll(dir) }, "Scrolling $dir.")
        }
        m = Regex("^(?:click|tap|press|select) (?:on )?(?:the )?(.+)$").find(s)
        if (m != null) {
            val label = m.groupValues[1]
            return a11y({ it.clickLabel(label) }, "Tapped $label.").let {
                if (it == "I couldn't do that.") "I couldn't find $label on the screen." else it
            }
        }

        // web and apps
        m = Regex("^(?:play) (.+?)(?: on youtube)?$").find(s)
        if (m != null) {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(m.groupValues[1]))))
            return "Playing ${m.groupValues[1]} on YouTube."
        }
        m = Regex("^(?:search|google|look up)(?: for)? (.+)$").find(s)
        if (m != null) {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(m.groupValues[1]))))
            return "Searching for ${m.groupValues[1]}."
        }
        m = Regex("^(?:navigate|directions?|take me) to (.+)$").find(s)
        if (m != null) {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(m.groupValues[1]))))
            return "Getting directions to ${m.groupValues[1]}."
        }
        if (s == "open settings" || s == "open the settings") {
            launch(Intent(Settings.ACTION_SETTINGS)); return "Opening settings."
        }
        if (s.contains("wifi settings") || s.contains("wi-fi settings")) {
            launch(Intent(Settings.ACTION_WIFI_SETTINGS)); return "Opening Wi-Fi settings."
        }
        if (s.contains("bluetooth settings")) {
            launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Opening Bluetooth settings."
        }
        m = Regex("^(?:open|launch|start) (?:the )?(.+?)(?: app)?$").find(s)
        if (m != null) return openApp(m.groupValues[1])

        return null
    }
}
