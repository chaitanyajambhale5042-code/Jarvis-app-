package com.jarvis.assistant

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var key: String
        get() = sp.getString("key", "") ?: ""
        set(v) { sp.edit().putString("key", v).apply() }

    var name: String
        get() = sp.getString("name", "sir") ?: "sir"
        set(v) { sp.edit().putString("name", v).apply() }

    var model: String
        get() = sp.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) { sp.edit().putString("model", v).apply() }

    /** Country code added to 10-digit numbers (India by default). */
    var country: String
        get() = sp.getString("country", "91") ?: "91"
        set(v) { sp.edit().putString("country", v).apply() }
}
