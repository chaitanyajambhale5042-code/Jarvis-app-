# Jarvis for Galaxy Tab A9+ (native Android app)

Hands-free voice assistant. Say "Jarvis, call Mom" and it calls, with no tap.

## Build and install

1. Install Android Studio (free) on a computer: developer.android.com/studio
2. Open Android Studio, choose **Open**, and select this `JarvisApp` folder. Let Gradle sync finish (first time takes a few minutes and downloads things).
3. On the tablet: Settings > About tablet > Software information > tap **Build number** 7 times, then Settings > Developer options > turn on **USB debugging** (or **Wireless debugging**).
4. Connect the tablet by USB cable and accept the prompt on the tablet.
5. In Android Studio pick the tablet in the device list and press the green **Run** button.

Or: Build > Build APK(s), copy `app/build/outputs/apk/debug/app-debug.apk` to the tablet and open it.

## First-time setup (inside the Jarvis app)

1. Paste your free Gemini key (aistudio.google.com/apikey), tap **Save settings**.
2. Tap each numbered button: permissions, display over other apps, Accessibility, battery.
3. Tap **Start Jarvis**.

If Accessibility is greyed out: Settings > Apps > Jarvis > top-right menu > **Allow restricted settings**, then try again.

## What to say (start with "Jarvis")

- Calls: "call Mom", "call 98765 43210"
- Texts: "text Rahul saying I'm on my way"
- WhatsApp: "WhatsApp Mom saying hello"
- Apps: "open YouTube", "open settings"
- Alarms/timers: "set a timer for 5 minutes", "set an alarm for 7 30 am"
- Screen: "go back", "go home", "scroll down", "tap Send", "take a screenshot", "lock the screen", "show notifications"
- Phone: "volume up", "what's the battery", "flashlight on" (if the tablet has one)
- Anything else goes to Gemini.
